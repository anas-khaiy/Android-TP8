<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    include_once '../service/EtudiantService.php';
    $id = $_POST['id']; // get id from request

    $es = new EtudiantService();
    $es->deleteById($id); // call a method that deletes by id

    header('Content-Type: application/json');
    echo json_encode(['status' => 'success']);
}
?>