<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

include_once '../classes/Etudiant.php';
include_once '../service/EtudiantService.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (!isset($_POST['id'], $_POST['nom'], $_POST['prenom'], $_POST['ville'], $_POST['sexe'])) {
        echo json_encode(["success" => false, "message" => "Paramètres manquants"]);
        exit();
    }

    $id = $_POST['id'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $ville = $_POST['ville'];
    $sexe = $_POST['sexe'];

    // objet étudiant
    $etudiant = new Etudiant($id, $nom, $prenom, $ville, $sexe);

    $service = new EtudiantService();

    try {
        $service->update($etudiant);
        echo json_encode(["success" => true, "message" => "Étudiant modifié avec succès"]);
    } catch (Exception $e) {
        echo json_encode(["success" => false, "message" => "Erreur : " . $e->getMessage()]);
    }

} else {
    echo json_encode(["success" => false, "message" => "Méthode non autorisée"]);
}
